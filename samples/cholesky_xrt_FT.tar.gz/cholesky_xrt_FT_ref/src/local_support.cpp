#include "heartbeat.h"
#include "ckpt_mem_def.h"
#include "my_timer.h"
#include <string.h>
#include <fstream>
#include <iostream>
#include <unistd.h>    /* standard unix functions, like alarm()          */
#include <signal.h>
#include <thread>
#include <stdexcept>
#include <sys/types.h>
#include <vector>
#include <functional>

#include <sys/mman.h>
#include <stdlib.h>

#define _POSIX_SOURCE
#include <sys/wait.h>

#define DEBUG_PRINT

#ifdef FPGA_TARGET
// XRT includes
#include "xrt/xrt_bo.h"
#include <experimental/xrt_xclbin.h>
#include "xrt/xrt_device.h"
#include "xrt/xrt_kernel.h"
#endif

#include "matrixUtility.hpp"
#include "cholesky_kernel.hpp"

#define HEARTBEAT_PERIOD_US 100000 //100ms
#define METADATA_NUM 3
#define CKPT_SIZE (int(CKPT_MEM_SIZE/sizeof(dataType))+METADATA_NUM)

volatile bool keep_watchdog = true;
static bool running_cpu_kernel = false;
volatile bool is_child_complete = false;

volatile bool backup_thread_running = false;

xrt::bo ckpt_buffer;
xrt::bo heartbeat_buffer;

dataType mem_ckpt[CKPT_SIZE];
dataType mem_ckpt_valid[CKPT_SIZE];
unsigned int g_heartbeat[2] = {5, 5};

extern "C" timespec timerRestore;

int arrToFile(dataType* arr, int arrSize, std::string filename) {
  std::ofstream myfile (filename);
  if (myfile.is_open()) {
    for(int i=0; i < arrSize; i ++) {
      myfile << arr[i] << "\n";
    }
    myfile.close();
    return 1;
  }
  else std::cout << "Unable to open file";
  return 0;
}

int arr2DToFile(dataType** arr, int arrDiag, std::string filename) {
  std::ofstream myfile (filename);
  if (myfile.is_open()) {
    for(int i=0; i < arrDiag; i++) {
      for(int j=0; j < arrDiag; j++) {
	myfile << arr[i][j] << "\n";
      }
    }
    myfile.close();
    return 1;
  }
  else std::cout << "Unable to open file";
  return 0;
}


// Memory alignment
template <typename T>
T* aligned_alloc(std::size_t num) {
    void* ptr = nullptr;
    if (posix_memalign(&ptr, 4096, num * sizeof(T))) {
        throw std::bad_alloc();
    }
    return reinterpret_cast<T*>(ptr);
}

// Compute time difference
unsigned long diff(const struct timeval* newTime, const struct timeval* oldTime) {
    return (newTime->tv_sec - oldTime->tv_sec) * 1000000 + (newTime->tv_usec - oldTime->tv_usec);
}

// Arguments parser
class ArgParser {
   public:
    ArgParser(int& argc, const char** argv) {
        for (int i = 1; i < argc; ++i) mTokens.push_back(std::string(argv[i]));
    }
    bool getCmdOption(const std::string option, std::string& value) const {
        std::vector<std::string>::const_iterator itr;
        itr = std::find(this->mTokens.begin(), this->mTokens.end(), option);
        if (itr != this->mTokens.end() && ++itr != this->mTokens.end()) {
            value = *itr;
            return true;
        }
        return false;
    }

   private:
    std::vector<std::string> mTokens;
};


/** Thread simulating the application crash */
void killer_thread(int delay_ms){
  usleep(delay_ms*1000);
  printf("Early stop\n");
  kill(getpid(), 9);
}

void backup_thread(int diagSize, dataType* dataA){
  // printf("Restore ID = %f\n", mem_ckpt[CKPT_ID]);
  printf("Restore ID = %f \n", mem_ckpt[CKPT_ID]);
  printf("(valid) Restore ID = %f i %f \n", mem_ckpt_valid[CKPT_ID], mem_ckpt_valid[CKPT_ID]);
  printf("diagSize %d  dataA %p\n", diagSize, dataA);
  arrToFile(mem_ckpt_valid, CKPT_SIZE, "mem_ckpt.txt");
  timespec timer3 = tic();
  cholesky_kernel(diagSize, dataA, 1, mem_ckpt_valid);
  toc(&timer3, "Final computation CPU");
  memcpy(mem_ckpt, mem_ckpt_valid,  CKPT_SIZE*sizeof(dataType));
}

void watchdog(int diagSize, dataType* dataA)
{
  static int previous_heartbeat = 0;

  memset(mem_ckpt_valid, 0, CKPT_SIZE*sizeof(dataType));

  for(int i=0; i<10; i++){
      printf("watch mem_ckpt[%d] = %f\n", i, mem_ckpt[i]);
  }
  
  while(keep_watchdog){
    // Get last checkpoint
#ifdef FPGA_TARGET
    printf("Ckpt backup\n");
    ckpt_buffer.sync(XCL_BO_SYNC_BO_FROM_DEVICE);
    ckpt_buffer.read(mem_ckpt);
    heartbeat_buffer.sync(XCL_BO_SYNC_BO_FROM_DEVICE);
    heartbeat_buffer.read(g_heartbeat);

    if(mem_ckpt[CKPT_ID] != -1){
      memcpy(mem_ckpt_valid, mem_ckpt, CKPT_SIZE*sizeof(dataType));
    }
    
    //printf("Data transfered\n");
    //for(int i=0; i<5; i++){
    //printf("mem_ckpt[%d] = %f\n", 1, mem_ckpt[1]);
    printf("mem_ckpt[%d] = %f\n", 4, mem_ckpt[4]);
    //}

#endif
#ifdef DEBUG_PRINT
    printf("watchdog => prev HB %d new HB %d\n", previous_heartbeat, g_heartbeat[0]);
#endif
    // is it alive (heartbeat check)
    if((g_heartbeat[0] == previous_heartbeat) && (!backup_thread_running) && (previous_heartbeat>0)){
#ifdef DEBUG_PRINT
      printf("FAILURE DETECTED. RUN BACKUP\n");
#endif
      // kernel ckpt has not been updated in time => recovery process
      backup_thread_running = true;
      backup_thread(diagSize, dataA);
      break;
    }
    previous_heartbeat = g_heartbeat[0];
    usleep(HEARTBEAT_PERIOD_US);
  }
}



int main(int argc, const char** argv) {
  // Initialize parser
  ArgParser parser(argc, argv);

  // Initialize paths addresses
  std::string xclbin_path;
  std::string num_str;
  int num_runs, dataAM, dataAN, seed;
  int failure_delay_ticks = 1000;
  int rate = 1;
  
  // Read In paths addresses
  if (!parser.getCmdOption("-xclbin", xclbin_path)) {
    std::cout << "INFO:input path is not set!\n";
  }
  if (!parser.getCmdOption("-runs", num_str)) {
    num_runs = 1;
    std::cout << "INFO:number runs is not set!\n";
  } else {
    num_runs = std::stoi(num_str);
  }
  if (!parser.getCmdOption("-M", num_str)) {
    dataAM = 16;
    std::cout << "INFO:row size M is not set!\n";
  } else {
    dataAM = std::stoi(num_str);
  }
  if (!parser.getCmdOption("-N", num_str)) {
    dataAN = 16;
    std::cout << "INFO:column size N is not set!\n";
  } else {
    dataAN = std::stoi(num_str);
  }
  if (!parser.getCmdOption("-seed", num_str)) {
    seed = 12;
    std::cout << "INFO:seed is not set!\n";
  } else {
    seed = std::stoi(num_str);
  }
  if (!parser.getCmdOption("-failure", num_str)) {
    std::cout << "INFO:Failure delay not set!\n";
  } else {
    failure_delay_ticks = std::stoi(num_str);
  }
  if (!parser.getCmdOption("-rate", num_str)) {
    std::cout << "INFO:Rate not set!\n";
  } else {
    rate = std::stoi(num_str);
  }
  
  // dataAM = dataAN is valid only for symmetric matrix
  dataAM = MAXN_K; //(dataAM > dataAN) ? dataAN : dataAM;
  dataAN = dataAM;
  
  // Read settings
  std::string binaryFile = "xclbin/cholesky_kernel.hw.xilinx_u50_gen3x16_xdma_201920_3.xclbin"; 
  int device_index = 0;
  
  std::cout << "Open the device" << device_index << std::endl;
  auto device = xrt::device(device_index);
  std::cout << "Load the xclbin " << binaryFile << std::endl;
  auto uuid = device.load_xclbin(binaryFile);

  auto krnl = xrt::kernel(device, uuid, "cholesky_kernel", xrt::kernel::cu_access_mode::exclusive);
  auto krnl2 = xrt::kernel(device, uuid, "heartbeat", xrt::kernel::cu_access_mode::exclusive);

  // Output the inputs information
  std::cout << "INFO: Number of kernel runs: " << num_runs << std::endl;
  std::cout << "INFO: Matrix Row M: " << dataAM << std::endl;
  std::cout << "INFO: Matrix Col N: " << dataAN << std::endl;
  std::cout << "INFO: Failure delay: " << failure_delay_ticks << std::endl;

  const int MAXN = dataAN;
  const int LDA = dataAN;
  int inout_size = MAXN * MAXN;
  dataType* dataA;
  dataA = aligned_alloc<dataType>(inout_size);

  std::cout << "Allocate Buffer in Global Memory CKPT_SIZE = " << CKPT_SIZE << std::endl;

  auto dataA_buffer = xrt::bo(device, inout_size*sizeof(dataType), krnl.group_id(1)); //Match kernel arguments to RTL kernel

  heartbeat_buffer = xrt::bo(device, 2*sizeof(unsigned int), krnl2.group_id(1)); //Match kernel arguments to RTL kernel

  ckpt_buffer = xrt::bo(device, CKPT_SIZE*sizeof(dataType), krnl.group_id(3)); //Match kernel arguments to RTL kernel

  // Generate general matrix dataAM x dataAN
  dataType** dataC = new dataType*[dataAM];
  dataType** dataD = new dataType*[dataAM];
  dataType** dataE = new dataType*[dataAM];
  for (int i = 0; i < dataAM; ++i) {
    dataC[i] = new dataType[dataAN];
    dataD[i] = new dataType[dataAN];
    dataE[i] = new dataType[dataAN];
  }
  triLowerMatGen<dataType>(dataAN, seed, dataC);
  transposeMat<dataType>(dataAN, dataC, dataD);
  MulMat<dataType>(dataAM, dataAN, dataAN, dataC, dataD, dataE);
  
  for (int i = 0; i < dataAM; ++i) {
    for (int j = 0; j < dataAN; ++j) {
      dataA[i * LDA + j] = dataE[i][j];
    }
  }
  
  std::cout << "XRT Buffer ok\n";

  //reset mem_ckpt
  memset(mem_ckpt, 0, CKPT_SIZE*sizeof(dataType));

  printf("Start Kernel computation\n");

  mem_ckpt[COMPLETED] = 0;

  // 0th: initialize the timer at the beginning of the program
  timespec timer = tic();
  
  // Write our data set into device buffers
  dataA_buffer.write(dataA);
  dataA_buffer.sync(XCL_BO_SYNC_BO_TO_DEVICE);

  ckpt_buffer.write(mem_ckpt);
  ckpt_buffer.sync(XCL_BO_SYNC_BO_TO_DEVICE);
  
  // Execute the kernel over the entire range of our 1d input data set
  // using the maximum number of work group items for this device
  //
  
  //ualarm(BACKUP_PERIOD_US, 0);
  std::thread thread_obj(watchdog, dataAN, dataA);

  //std::thread killer_tid = std::thread(killer_thread, failure_delay_ms);
  
  std::cout << "Execution of the kernel\n";
  auto run2 = krnl2(failure_delay_ticks, heartbeat_buffer);
  auto run = krnl(dataAN, dataA_buffer, rate, ckpt_buffer);
  printf("wait\n");
  //run.wait();
  //run2.wait();

  //cholesky_kernel(dataAN, dataA, 1, mem_ckpt);
  

  while(mem_ckpt[COMPLETED] != 1){usleep(20);}
  
  
  // 4th: time of kernel execution
  toc(&timer, "kernel execution");

  //heartbeat_buffer.sync(XCL_BO_SYNC_BO_FROM_DEVICE);
  //heartbeat_buffer.read(g_heartbeat);
  //printf("=> g_heartbeat[0] = %d\n", g_heartbeat[0]);
  //printf("=> g_heartbeat[1] = %d\n", g_heartbeat[1]);
  
  // Read back the results from the device to verify the output
  if(!backup_thread_running){
    // Data transfer from device buffer to host buffer
    dataA_buffer.sync(XCL_BO_SYNC_BO_FROM_DEVICE);
    dataA_buffer.read(dataA);
    ckpt_buffer.sync(XCL_BO_SYNC_BO_FROM_DEVICE);
    ckpt_buffer.read(mem_ckpt);
    
    // 5th: time of data retrieving (PCIe + memcpy)
    toc(&timer, "data retrieving");
  }
  // Register restore functions

  //run2.wait();
  //heartbeat_buffer.sync(XCL_BO_SYNC_BO_FROM_DEVICE);
  //heartbeat_buffer.read(g_heartbeat);  
  //printf("heartbeat %d\n", g_heartbeat[0]);  

  for(int i=0; i<11; i++){
    printf("end mem_ckpt[%d] = %f\n", i, mem_ckpt[i]);
  }
    
  keep_watchdog = false;
  thread_obj.join();

  if(mem_ckpt[COMPLETED] == 1){
    printf("Application completed");
    // Calculate err between dataA and dataC
    double errA = 0;
    for (int i = 0; i < dataAM; i++) {
        for (int j = 0; j <= i; j++) {
            errA += (dataA[i * LDA + j] - dataC[i][j]) * (dataA[i * LDA + j] - dataC[i][j]);
        }
    }

    arrToFile(dataA, MAXN_K*MAXN_K, "computedData.txt");
    arr2DToFile(dataC, MAXN_K, "reference.txt");
    arrToFile(mem_ckpt, CKPT_SIZE, "mem_ckpt_final.txt");
    
    errA = std::sqrt(errA);
    std::cout << "errA = " << errA << std::endl;
    std::cout << "dataAN = " << dataAN << std::endl;
    std::cout << "dataAM = " << dataAM << std::endl;
    std::cout << "-------------- " << std::endl;
    if (errA > 0.0001) {
        std::cout << "INFO: Result false" << std::endl;
        std::cout << "-------------- " << std::endl;
        return -1;
    } else {
        std::cout << "INFO: Result correct" << std::endl;
        std::cout << "-------------- " << std::endl;
        return 0;
    }
  }
    
  printf("\n free memory\n");
  delete[] dataA;
}
