/*
 * Copyright 2020 Xilinx, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include "cholesky_kernel.hpp"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>


extern "C" {

  char sync_bit = 0;
  int call_cpt = 0;

  void cpy_wrapper_f(dataType* dest, dataType* src, int size){
    memcpy(dest, src, size);
    sync_bit = 1;
  }

  void cpy_wrapper_i8(unsigned char* dest, unsigned char* src, int size){
    memcpy(dest, src, size);
    sync_bit = 1;
  }

  /*
  void  __attribute__ ((noinline)) push_stack(int* stack_ptr, int* sp, int value){
    if(stack_ptr == NULL){
      printf("NULL stack ptr \n");
      return;
    }
      
    printf("stack[%d]=%d (%p)\n", *sp, value, stack_ptr);
    stack_ptr[*sp] = value;
  }
  */
  void __attribute__ ((noinline)) mem_cpy_index_f(dataType* dest, dataType* src, int* index_list, int* sp){
    if(dest == NULL)
      return;

    /*
    if((call_cpt%2) == 0)
      dest[2] = *sp;
    else
      dest[1] = *sp;
    call_cpt++;
    
    int i=0;
    */    
    while(*sp>0){
      (*sp)--;
      int index = index_list[*sp];
      dest[index] = src[index];
      //dest[i] = index; //src[index];
      //i++;
    }

    /*
    for(i=10; i<20; i++){
      dest[i] = i;
    }
    */
    sync_bit = 1;
  }

  void checkpoint(){mem_cpy_index_f(NULL, NULL, NULL, NULL);cpy_wrapper_f(NULL, NULL, 0);cpy_wrapper_i8(NULL, NULL, 0);}

  /*#FUNCTION_DEF#*/
  /* FUNC cholesky_kernel : ARGS matrixA[262144] */
  void cholesky_kernel(int diagSize, dataType matrixA[262144], int rate, dataType* ckpt_mem) {
    int i=0, j, k;
    dataType tmp, tmp1, tmp2;
    //dataType dataA[MAXN_K][MAXN_K];
    dataType dataA[MAXN_K*MAXN_K];
    
    //int fake_stack[1];
    //push_stack(fake_stack, &i, 0);
    
    //printf("cholesky_kernel\n");
    //printf("ckpt_mem[3] = %f\n", ckpt_mem[3]);

    printf("First loop write to dataA (Array) from matrixA (ptr)\n");
    for(i = 0; i < diagSize; i++){
      for(j = 0; j < diagSize; j++) {
	//dataA[i][j] = matrixA[i*diagSize + j];
	dataA[i*diagSize+j] = matrixA[i*diagSize + j];
      }
    }
    
    tmp1=sqrt(dataA[0]);
    
    dataA[0] = tmp1;
  Loop_first_col:
    printf("Second loop write to dataA (Array) from dataA (Array)\n");
    for (i = 1; i < diagSize; i++){
      dataA[i*diagSize+0] = dataA[i*diagSize+0]/tmp1;
    }
    
  Loop_col:
    for (j = 1; j < diagSize; ++j){
      tmp = 0;
      
    Loop_diag:
      for(k = 0; k < j; k++){
	tmp += dataA[j*diagSize+k]*dataA[j*diagSize+k];
      }

      printf("Write to dataA (Array) from dataA (Array)\n");
      dataA[j*diagSize+j] = sqrt(dataA[j*diagSize+j] - tmp);

      printf("Third loop write to dataA (Array) from dataA (Array)\n");
      if (j < diagSize - 1){
      Loop_row:
	for(i = j+1; i < diagSize; ++i){
	  tmp2=0;
	Loop_vec_mul:
	  for(k = 0; k < j; k++){
            tmp2 += dataA[i*diagSize+k]*dataA[j*diagSize+k];
	  }
	  dataA[i*diagSize+j] = (dataA[i*diagSize+j] - tmp2)/dataA[j*diagSize+j];
	}
      }
      if((j%rate) == 0){
      io_section:{
#pragma HLS protocol fixed  
	  checkpoint();
	  ap_wait_until(sync_bit);
	}
      }
      /*
      if((j%rate)==0)
	checkpoint();
      printf("%d \n", j);
      */
    }

    printf("Last loop write to matrixA (ptr) from dataA (array)\n");
    for (i = 0; i < diagSize; i++) {
      for (j = 0; j < diagSize; j++) {
	matrixA[i * diagSize + j] = dataA[i*diagSize+j];
      }
    }
    //printf("end kernel\n");
    //printf("ckpt_mem[3] = %f\n", ckpt_mem[3]);
  }
  
}
